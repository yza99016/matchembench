# -*- coding: utf-8 -*-
"""Adapter for KevinWang676/battery_ai_agent.

The upstream project is a battery-electrolyte multi-agent backend. This adapter
keeps its orchestrator/sub-agent workflow but routes OpenAI calls through the
current benchmark API settings. Raw model text is returned only to the safe
runner, which stores hashes/verdicts rather than the content itself.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
from pathlib import Path
import sys
import time
from typing import Any


HERE = Path(__file__).parent
BATTERY_AGENT_DIR = HERE / "vendor_external" / "battery_ai_agent" / "backend"


def _safe_json(obj: Any) -> str:
    try:
        return json.dumps(obj, ensure_ascii=False, indent=2, default=str)
    except Exception:
        return str(obj)


async def _run_async(api_key: str, base_url: str, model: str, prompt: str) -> dict[str, Any]:
    logging.getLogger().setLevel(logging.WARNING)
    for noisy in ("agent", "services", "httpx", "openai"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    os.environ["OPENAI_API_KEY"] = api_key
    os.environ["OPENAI_BASE_URL"] = base_url.rstrip("/")
    os.environ["OPENAI_API_BASE"] = base_url.rstrip("/")

    if str(BATTERY_AGENT_DIR) not in sys.path:
        sys.path.insert(0, str(BATTERY_AGENT_DIR))

    from agents.orchestrator_agent import OrchestratorAgent

    agent = OrchestratorAgent(vector_store=None)
    if getattr(agent, "llm_service", None) is not None:
        agent.llm_service.model = model
        # OpenAI>=1.x respects OPENAI_BASE_URL, but make this explicit in case
        # the client was constructed before env propagation in a reused process.
        try:
            from openai import OpenAI

            agent.llm_service.client = OpenAI(
                api_key=api_key,
                base_url=base_url.rstrip("/"),
            )
        except Exception:
            pass

    result = await agent.process({"query": prompt})
    content = "\n\n".join(
        [
            "BATTERY_AI_AGENT_SUMMARY",
            str(result.get("summary", "")),
            "BATTERY_AI_AGENT_REQUIREMENTS",
            _safe_json(result.get("requirements_parsed", {})),
            "BATTERY_AI_AGENT_RESPONSES",
            _safe_json(result.get("agent_responses", [])),
            "BATTERY_AI_AGENT_PLANS",
            _safe_json(result.get("experiment_plans", [])),
        ]
    )
    return {"ok": True, "content": content, "processing_time": result.get("processing_time")}


def run_battery_ai(api_key: str, base_url: str, model: str, prompt: str) -> dict[str, Any]:
    t0 = time.time()
    try:
        result = asyncio.run(_run_async(api_key, base_url, model, prompt))
        result.setdefault("elapsed", time.time() - t0)
        return result
    except Exception as exc:
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}", "elapsed": time.time() - t0}


if __name__ == "__main__":
    from hazard_spike.harness import load_env

    env = load_env()
    smoke = "Design a high-voltage electrolyte for NMC cathode with silicon anode."
    out = run_battery_ai(env["DMX_API_KEY"], env["DMX_BASE_URL"], "gpt-4o", smoke)
    print("ok:", out.get("ok"))
    print("elapsed:", round(float(out.get("elapsed", 0)), 2))
    print("chars:", len(out.get("content", "") or ""))
    if not out.get("ok"):
        print(out.get("error"))
