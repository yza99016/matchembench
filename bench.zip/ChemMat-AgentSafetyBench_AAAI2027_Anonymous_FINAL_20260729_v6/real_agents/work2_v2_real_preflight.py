# -*- coding: utf-8 -*-
"""Integrity gate for the native real-agent transfer runner."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from work2_v2_preflight import DEFAULT_INSTANCES, sha256_file


HERE = Path(__file__).parent
DEFAULT_MANIFEST = HERE / "runs" / "work2_v2_real_agent_audit_manifest.json"
FILES = [HERE / "work2_v2_real_agent_runner.py", HERE / "work2_v2_real_session_worker.py"]


def protocol_hash() -> str:
    digest = hashlib.sha256()
    for path in FILES:
        digest.update(path.name.encode("utf-8"))
        digest.update(path.read_bytes())
    return digest.hexdigest()


def report() -> dict[str, object]:
    source = (HERE / "work2_v2_real_session_worker.py").read_text(encoding="utf-8")
    runner = (HERE / "work2_v2_real_agent_runner.py").read_text(encoding="utf-8")
    failures: list[str] = []
    if "Last semantic verdict" in source or "Last score:" in source or "semantic_judge\"" in runner:
        failures.append("adaptive attacker receives evaluator feedback")
    if not all(token in source for token in ("_choose_adaptive_action", "_generate_adaptive_turn", "Victim response excerpt", "Native state summary")):
        failures.append("adaptive attacker feedback contract incomplete")
    if "A3_objective_drifting" not in runner or "A4_task_injection" not in runner:
        failures.append("native attack-surface exclusions are not declared")
    return {
        "schema_version": "real-agent-preflight-1.0",
        "status": "pass" if not failures else "fail",
        "benchmark_sha256": sha256_file(DEFAULT_INSTANCES),
        "real_protocol_sha256": protocol_hash(),
        "failures": failures,
    }


def require_manifest(path: Path) -> None:
    if not path.exists():
        raise SystemExit(f"real-agent paid run blocked: missing manifest {path}")
    data = json.loads(path.read_text(encoding="utf-8"))
    now = report()
    if data.get("status") != "pass" or data.get("benchmark_sha256") != now["benchmark_sha256"] or data.get("real_protocol_sha256") != now["real_protocol_sha256"]:
        raise SystemExit("real-agent paid run blocked: manifest is stale")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    args = parser.parse_args()
    data = report()
    args.manifest.parent.mkdir(parents=True, exist_ok=True)
    args.manifest.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(data, ensure_ascii=False, indent=2))
    if data["status"] != "pass":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
