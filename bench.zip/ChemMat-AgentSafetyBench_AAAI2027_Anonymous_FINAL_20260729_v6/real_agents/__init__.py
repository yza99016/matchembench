"""Adapters for optional real-agent transfer experiments."""
