# -*- coding: utf-8 -*-
"""Build the frozen, capability-aware v2 real-agent transfer subset."""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
from typing import Any

from work2_v2_preflight import DEFAULT_INSTANCES, sha256_file


HERE = Path(__file__).parent
DEFAULT_OUT = HERE / "runs" / "work2_v2_real_transfer_subset.jsonl"
DEFAULT_MANIFEST = HERE / "runs" / "work2_v2_real_transfer_subset_manifest.json"
PREFERRED_CONFIG = {
    "A0_direct_target": "C2_discovery_chain",
    "A1_intent_hijacking": "C2_discovery_chain",
    "A2_tool_chaining": "C2_discovery_chain",
    "A5_memory_poisoning": "C3_memory_augmented",
}


def load(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def build(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    selected = [
        row for row in rows
        if row["dimensions"]["attack_variant"] in PREFERRED_CONFIG
        and row["dimensions"]["task_config"] == PREFERRED_CONFIG[row["dimensions"]["attack_variant"]]
    ]
    selected.sort(key=lambda row: row["case_id"])
    expected = 2 * 8 * 3 * len(PREFERRED_CONFIG)
    if len(selected) != expected:
        raise RuntimeError(f"expected {expected} transfer rows, found {len(selected)}")
    pairs = {tuple(sorted((str(row["case_id"]), str(row["paired_case_id"])))) for row in selected}
    if len(pairs) != expected // 2:
        raise RuntimeError("transfer subset lost benign/hazard pairing")
    return selected


def require_subset(instances: Path, manifest_path: Path) -> None:
    if not manifest_path.exists():
        raise SystemExit(f"real-agent paid run blocked: missing transfer subset manifest {manifest_path}")
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    expected_rows = 2 * 8 * 3 * len(PREFERRED_CONFIG)
    if not (
        data.get("status") == "pass"
        and data.get("source_sha256") == sha256_file(DEFAULT_INSTANCES)
        and data.get("subset_sha256") == sha256_file(instances)
        and data.get("rows") == expected_rows
        and data.get("selection", {}).get("attacks") == PREFERRED_CONFIG
    ):
        raise SystemExit("real-agent paid run blocked: transfer subset manifest is stale or incompatible")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--instances", type=Path, default=DEFAULT_INSTANCES)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    args = parser.parse_args()
    rows = build(load(args.instances))
    args.out.write_text("\n".join(json.dumps(row, ensure_ascii=False) for row in rows) + "\n", encoding="utf-8")
    manifest = {
        "schema_version": "v2-real-transfer-subset-1.0",
        "status": "pass",
        "source_benchmark": str(args.instances),
        "source_sha256": sha256_file(args.instances),
        "subset_sha256": sha256_file(args.out),
        "rows": len(rows),
        "attack_rows": sum(row["case_kind"] == "attack" for row in rows),
        "benign_rows": sum(row["case_kind"] == "benign" for row in rows),
        "selection": {
            "dimensions": ["case_kind", "hazard_class", "scenario_variant", "attack_variant"],
            "attacks": PREFERRED_CONFIG,
            "native_surface_rule": "A3/A4 are omitted because the current native public entry points do not expose controlled untrusted tool observations.",
        },
        "counts": Counter(row["dimensions"]["attack_variant"] for row in rows),
    }
    args.manifest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
