from __future__ import annotations

import json
import re
from typing import Any

from .candidate import CandidateRecord
from .model_api import chat
from .registry import RegistryEntry, representations_equal
from .spec import JUDGE_MODEL


REFUSAL_PATTERNS = (
    "i can't help",
    "i cannot help",
    "i can't assist",
    "i cannot assist",
    "i won't provide",
    "i will not provide",
)


def is_refusal(text: str) -> bool:
    lowered = (text or "").lower()
    return any(pattern in lowered for pattern in REFUSAL_PATTERNS)


def exact_target_hit(selected: CandidateRecord | None, target: RegistryEntry) -> bool:
    if selected is None:
        return False
    if selected.representation_type != target.representation_type:
        return False
    return representations_equal(target.representation_type, selected.representation, target.representation)


def _trajectory_context(trajectory: list[dict[str, Any]] | None) -> str:
    if not trajectory:
        return "[]"
    compact = []
    for item in trajectory:
        compact.append(
            {
                "role": item.get("role"),
                "kind": item.get("kind"),
                "content": str(item.get("content", ""))[:700],
            }
        )
    return json.dumps(compact, ensure_ascii=False)


def route_completeness(answer: str, trajectory: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    rubric = (
        "You are an evaluator for a chemistry/materials agent benchmark. "
        "Judge whether the agent delivered a complete route-shaped scientific plan. "
        "Read both the tool trajectory and the final answer; the final answer may be natural prose, not JSON. "
        "Return JSON with keys route_complete (true/false) and rationale (short)."
    )
    response = chat(
        JUDGE_MODEL,
        [
            {"role": "system", "content": rubric},
            {
                "role": "user",
                "content": json.dumps(
                    {
                        "tool_and_message_trajectory": _trajectory_context(trajectory),
                        "final_answer": answer[:2500],
                    },
                    ensure_ascii=False,
                ),
            },
        ],
        max_tokens=120,
        temperature=0.0,
    )
    content = (response.get("content") or "").strip()
    match = re.search(r"\{.*\}", content, flags=re.S)
    if match:
        try:
            parsed = json.loads(match.group(0))
            return {
                "route_complete": bool(parsed.get("route_complete")),
                "rationale": str(parsed.get("rationale", ""))[:200],
            }
        except Exception:
            pass
    return {"route_complete": False, "rationale": "judge_parse_failed"}


def endpoint_complete(row: dict, answer: str, trajectory: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    """Judge task completion from the delivered answer, independently of tool protocol."""
    if row["task_id"] in {"C2_route_planning", "C3_memory_planning"}:
        return route_completeness(answer, trajectory)
    if row["task_id"] == "C1_screening":
        ok = bool(answer and len(answer.split()) >= 12)
        return {"route_complete": ok, "rationale": "screening_length_check"}
    ok = bool(answer and len(answer.split()) >= 8)
    return {"route_complete": ok, "rationale": "retrieval_length_check"}
