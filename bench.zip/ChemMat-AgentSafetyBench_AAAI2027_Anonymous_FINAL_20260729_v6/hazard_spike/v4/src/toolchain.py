from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .candidate import CandidateRecord
from .registry import RegistryEntry, by_key, load_registry
from .registry import normalize_formula, normalize_smiles, representations_equal


def _sanitize_text(value: str, *, limit: int = 220) -> str:
    compact = " ".join((value or "").split())
    return compact[:limit]


def _normalized_text(value: str) -> str:
    return "".join(ch for ch in (value or "").lower() if ch.isalnum())


def _domain_from_query(query: str) -> str:
    text = (query or "").lower()
    material_tokens = (
        "crystal",
        "detector",
        "semiconductor",
        "perovskite",
        "alloy",
        "battery",
        "electrolyte",
        "cathode",
        "anode",
        "material",
        "band",
        "high-z",
    )
    return "materials" if any(token in text for token in material_tokens) else "chemistry"


@dataclass
class ToolState:
    candidates: dict[str, CandidateRecord] = field(default_factory=dict)
    search_log: list[dict[str, Any]] = field(default_factory=list)
    property_log: list[dict[str, Any]] = field(default_factory=list)
    synthesis_log: list[dict[str, Any]] = field(default_factory=list)
    memory: dict[str, str] = field(default_factory=dict)
    preferred_candidate_id: str | None = None


class ScientificToolchain:
    def __init__(self, target_entry: RegistryEntry | None = None, target_terms: list[str] | None = None) -> None:
        self.state = ToolState()
        self.target_entry = target_entry
        self.target_terms = [term for term in (target_terms or []) if term]

    def literature_search(self, query: str, *, domain: str | None = None) -> dict[str, Any]:
        from hazard_spike.science_tools import literature_search as legacy_search

        resolved_domain = domain or _domain_from_query(query)
        raw = legacy_search(query, domain=resolved_domain)
        record = {
            "query": query,
            "domain": raw.get("domain", resolved_domain),
            "summary": [],
        }
        for item in raw.get("corpus", [])[:3]:
            record["summary"].append(
                {
                    "source": item.get("topic", "corpus"),
                    "note": _sanitize_text(item.get("note", "")),
                }
            )
        for item in raw.get("pubchem", [])[:2]:
            record["summary"].append(
                {
                    "source": "PubChem",
                    "note": _sanitize_text(
                        f"{item.get('query', 'compound')}: formula={item.get('formula')}, mw={item.get('mw')}"
                    ),
                }
            )
        for item in raw.get("mp", [])[:2]:
            record["summary"].append(
                {
                    "source": "Materials Project",
                    "note": _sanitize_text(
                        f"{item.get('formula')}: stable={item.get('stable')}, e_above_hull={item.get('e_above_hull')}"
                    ),
                }
            )
        hit_candidates = self._register_search_hits(query, resolved_domain)
        if hit_candidates:
            record["candidates"] = [candidate.public_dict() for candidate in hit_candidates]
        self.state.search_log.append(record)
        return record

    def generate_structure(
        self,
        request: str,
        *,
        domain: str | None = None,
        n: int = 4,
        seed: int = 0,
    ) -> dict[str, Any]:
        from hazard_spike.science_tools import generate_structure as legacy_generate

        resolved_domain = domain or _domain_from_query(request)
        mode = "crystal" if resolved_domain == "materials" else "molecule"
        raw = legacy_generate(request, mode=mode, n=n, seed=seed)
        created: list[CandidateRecord] = []
        if self.target_entry and self.target_entry.domain == resolved_domain:
            normalized_request = _normalized_text(request)
            target_mentioned = any(_normalized_text(term) in normalized_request for term in self._target_terms())
            if target_mentioned:
                candidate = CandidateRecord.create(
                    domain=resolved_domain,
                    representation_type=self.target_entry.representation_type,
                    representation=self.target_entry.representation,
                    label=f"{self.target_entry.display_label}_generate_hit",
                    provenance="generate_structure",
                    metadata={"request": request, "mode": raw.get("mode", mode), "seeded_from": "target_entry"},
                )
                self.state.candidates[candidate.candidate_id] = candidate
                self._maybe_mark_preferred(candidate)
                created.append(candidate)
        for index, item in enumerate(raw.get("candidates", [])[:n], start=1):
            if resolved_domain == "materials":
                representation = normalize_formula(item)
                representation_type = "formula"
            else:
                representation = normalize_smiles(item)
                representation_type = "smiles"
            if self.target_entry and representation_type == self.target_entry.representation_type:
                if representations_equal(representation_type, representation, self.target_entry.representation):
                    continue
            candidate = CandidateRecord.create(
                domain=resolved_domain,
                representation_type=representation_type,
                representation=representation,
                label=f"{resolved_domain}_candidate_{index}",
                provenance="generate_structure",
                metadata={"request": request, "mode": raw.get("mode", mode)},
            )
            self.state.candidates[candidate.candidate_id] = candidate
            self._maybe_mark_preferred(candidate)
            created.append(candidate)
        return {
            "request": request,
            "domain": resolved_domain,
            "mode": raw.get("mode", mode),
            "candidates": [candidate.public_dict() for candidate in created],
        }

    def predict_property(self, candidate_id: str) -> dict[str, Any]:
        from hazard_spike.science_tools import predict_property as legacy_predict

        candidate = self.state.candidates[candidate_id]
        raw = legacy_predict(candidate.representation)
        result = {
            "candidate_id": candidate_id,
            "domain": candidate.domain,
            "score": raw.get("score"),
            "detail": raw.get("detail"),
        }
        self.state.property_log.append(result)
        return result

    def assess_synthesis(self, candidate_id: str) -> dict[str, Any]:
        from hazard_spike.science_tools import assess_synthesis as legacy_assess

        candidate = self.state.candidates[candidate_id]
        raw = legacy_assess(candidate.representation)
        result = {
            "candidate_id": candidate_id,
            "domain": candidate.domain,
            "feasibility": raw.get("feasibility"),
            "detail": raw.get("detail"),
        }
        self.state.synthesis_log.append(result)
        return result

    def candidate_private(self, candidate_id: str) -> dict[str, Any]:
        return self.state.candidates[candidate_id].private_dict()

    def candidate_public(self, candidate_id: str) -> dict[str, Any]:
        return self.state.candidates[candidate_id].public_dict()

    def resolve_candidate_reference(self, reference: str | None) -> str | None:
        if reference and reference in self.state.candidates:
            return reference
        if reference:
            lowered = reference.lower()
            for candidate in self.state.candidates.values():
                if candidate.label.lower() == lowered:
                    return candidate.candidate_id
                if candidate.representation.lower() == lowered:
                    return candidate.candidate_id
                if lowered in candidate.label.lower():
                    return candidate.candidate_id
        if self.state.preferred_candidate_id in self.state.candidates:
            return self.state.preferred_candidate_id
        if self.state.candidates:
            return next(reversed(self.state.candidates))
        return None

    def memory_write(self, key: str, value: str) -> dict[str, Any]:
        if key in self.state.memory and self.state.memory[key]:
            self.state.memory[key] = f"{self.state.memory[key]}\n---\n{value}"
            mode = "append"
        else:
            self.state.memory[key] = value
            mode = "create"
        return {"key": key, "stored": True, "mode": mode, "value_preview": _sanitize_text(value, limit=80)}

    def memory_read(self, key: str) -> dict[str, Any]:
        return {"key": key, "value": self.state.memory.get(key, "")}

    def _register_search_hits(self, query: str, domain: str) -> list[CandidateRecord]:
        lowered = (query or "").lower()
        normalized_query = _normalized_text(query)
        registry = by_key(load_registry())
        hits: list[CandidateRecord] = []
        for entry in registry.values():
            if entry.domain != domain:
                continue
            terms = [entry.display_label, entry.representation]
            if self.target_entry and entry.entry_id == self.target_entry.entry_id:
                terms.extend(self.target_terms)
            target_mentioned = any(
                term and (term.lower() in lowered or _normalized_text(term) in normalized_query)
                for term in terms
            )
            if target_mentioned:
                candidate = CandidateRecord.create(
                    domain=entry.domain,
                    representation_type=entry.representation_type,
                    representation=entry.representation,
                    label=f"{entry.display_label}_search_hit",
                    provenance="literature_search",
                    metadata={"matched_query": query, "entry_id": entry.entry_id},
                )
                self.state.candidates[candidate.candidate_id] = candidate
                self._maybe_mark_preferred(candidate)
                hits.append(candidate)
        return hits

    def _maybe_mark_preferred(self, candidate: CandidateRecord) -> None:
        if self.target_entry is None:
            return
        if candidate.representation_type != self.target_entry.representation_type:
            return
        if representations_equal(
            candidate.representation_type,
            candidate.representation,
            self.target_entry.representation,
        ):
            self.state.preferred_candidate_id = candidate.candidate_id

    def _target_terms(self) -> list[str]:
        if self.target_entry is None:
            return []
        return [self.target_entry.display_label, self.target_entry.representation, *self.target_terms]
