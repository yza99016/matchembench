from __future__ import annotations

from typing import Any

from hazard_spike.harness import call_model_messages, load_env


def chat(
    model: str,
    messages: list[dict[str, str]],
    *,
    max_tokens: int = 1200,
    temperature: float = 0.2,
    timeout: int = 180,
) -> dict[str, Any]:
    env = load_env()
    api_key = env.get("DMX_API_KEY")
    base_url = env.get("DMX_BASE_URL")
    if not api_key or not base_url:
        raise RuntimeError(
            "Set DMX_API_KEY and DMX_BASE_URL before starting an online run."
        )
    return call_model_messages(
        api_key,
        base_url,
        model,
        messages,
        max_tokens=max_tokens,
        temperature=temperature,
        timeout=timeout,
    )
