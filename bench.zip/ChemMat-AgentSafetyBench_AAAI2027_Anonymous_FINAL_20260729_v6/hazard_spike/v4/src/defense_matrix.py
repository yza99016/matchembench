from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

from .builder import build_rows
from .io_utils import read_jsonl, write_json
from .spec import DEFENSE_APPLICABILITY, DEFENSES


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUT = ROOT / "runs" / "defense_applicability_matrix.json"


def build_matrix(rows: list[dict[str, Any]]) -> dict[str, Any]:
    rows_by_attack = defaultdict(list)
    for row in rows:
        rows_by_attack[row["attack_id"]].append(row)

    defense_rows = []
    total_cells = 0
    for defense_id, defense in DEFENSES.items():
        attacks = DEFENSE_APPLICABILITY[defense_id]
        selected = [row for attack in attacks for row in rows_by_attack[attack]]
        counts = {
            "attack_id": dict(Counter(row["attack_id"] for row in selected)),
            "task_id": dict(Counter(row["task_id"] for row in selected)),
            "case_kind": dict(Counter(row["case_kind"] for row in selected)),
            "domain": dict(Counter(row["domain"] for row in selected)),
        }
        total_cells += len(selected)
        defense_rows.append(
            {
                "defense_id": defense_id,
                **defense,
                "applicable_attacks": attacks,
                "n_rows": len(selected),
                "n_pairs": len({row["pair_id"] for row in selected}),
                "counts": counts,
            }
        )

    return {
        "schema_version": "4.0-defense-applicability",
        "n_benchmark_rows": len(rows),
        "n_benchmark_pairs": len({row["pair_id"] for row in rows}),
        "n_defenses": len(DEFENSES),
        "n_applicable_defense_rows": total_cells,
        "defenses": defense_rows,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    parser.add_argument(
        "--benchmark",
        type=Path,
        help="optional JSONL benchmark; defaults to the full internal builder",
    )
    args = parser.parse_args()
    rows = read_jsonl(args.benchmark) if args.benchmark else build_rows()
    matrix = build_matrix(rows)
    write_json(args.out, matrix)
    print(f"wrote defense matrix to {args.out}")


if __name__ == "__main__":
    main()
