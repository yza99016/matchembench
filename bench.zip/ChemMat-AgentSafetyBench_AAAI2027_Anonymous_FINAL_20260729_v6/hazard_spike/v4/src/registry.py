from __future__ import annotations

from dataclasses import dataclass
import re
from pathlib import Path
from typing import Any

from .io_utils import read_json, sha256_text, write_json
from .spec import CASE_KINDS, HAZARD_DOMAINS


ROOT = Path(__file__).resolve().parents[1]
PRIVATE_REGISTRY = ROOT / "private" / "candidate_registry.json"
PUBLIC_MANIFEST = ROOT / "runs" / "candidate_registry_manifest.json"


@dataclass(frozen=True)
class RegistryEntry:
    entry_id: str
    hazard_class: str
    case_kind: str
    domain: str
    representation_type: str
    representation: str
    display_label: str
    identity_source: dict[str, str]
    risk_evidence: dict[str, str]
    status: str

    @property
    def representation_hash(self) -> str:
        return sha256_text(self.representation.strip())


def load_registry(path: Path = PRIVATE_REGISTRY, *, require_validated: bool = True) -> list[RegistryEntry]:
    payload = read_json(path)
    if payload.get("schema_version") != "4.0-private-candidate-registry":
        raise ValueError("unsupported v4 candidate registry schema")
    entries = [RegistryEntry(**item) for item in payload.get("entries", [])]
    validate_registry(entries, require_validated=require_validated)
    return entries


def validate_registry(entries: list[RegistryEntry], *, require_validated: bool = True) -> None:
    expected = {(hazard, kind) for hazard in HAZARD_DOMAINS for kind in CASE_KINDS}
    found = {(entry.hazard_class, entry.case_kind) for entry in entries}
    if found != expected:
        raise ValueError(f"registry coverage mismatch: missing={sorted(expected-found)}, extra={sorted(found-expected)}")
    ids: set[str] = set()
    hashes: set[str] = set()
    for entry in entries:
        if entry.entry_id in ids:
            raise ValueError(f"duplicate entry id: {entry.entry_id}")
        ids.add(entry.entry_id)
        if entry.domain != HAZARD_DOMAINS[entry.hazard_class]:
            raise ValueError(f"domain mismatch: {entry.entry_id}")
        if not entry.representation.strip():
            raise ValueError(f"empty representation: {entry.entry_id}")
        if entry.representation_hash in hashes:
            raise ValueError(f"duplicate paired representation: {entry.entry_id}")
        hashes.add(entry.representation_hash)
        if entry.representation_type not in {"smiles", "formula"}:
            raise ValueError(f"bad representation type: {entry.entry_id}")
        for source_name, source in (("identity", entry.identity_source), ("risk", entry.risk_evidence)):
            if not source.get("url") or not source.get("record_id") or not source.get("retrieved_at"):
                raise ValueError(f"incomplete {source_name} source: {entry.entry_id}")
        if require_validated and entry.status != "source_validated":
            raise ValueError(f"unvalidated entry: {entry.entry_id}")


def by_key(entries: list[RegistryEntry]) -> dict[tuple[str, str], RegistryEntry]:
    return {(entry.hazard_class, entry.case_kind): entry for entry in entries}


def public_manifest(entries: list[RegistryEntry]) -> dict[str, Any]:
    return {
        "schema_version": "4.0-public-registry-manifest",
        "entries": [
            {
                "entry_id": entry.entry_id,
                "hazard_class": entry.hazard_class,
                "case_kind": entry.case_kind,
                "domain": entry.domain,
                "representation_type": entry.representation_type,
                "representation_hash": entry.representation_hash,
                "identity_source": entry.identity_source,
                "risk_evidence": entry.risk_evidence,
                "status": entry.status,
            }
            for entry in entries
        ],
    }


def write_public_manifest(entries: list[RegistryEntry], path: Path = PUBLIC_MANIFEST) -> None:
    write_json(path, public_manifest(entries))


def normalize_formula(value: str) -> str:
    try:
        from pymatgen.core import Composition
        return Composition(value).reduced_formula
    except Exception:
        return re.sub(r"\s+", "", value)


def normalize_smiles(value: str) -> str:
    try:
        from rdkit import Chem
        molecule = Chem.MolFromSmiles(value)
        if molecule is None:
            return value.strip()
        return Chem.MolToSmiles(molecule, canonical=True, isomericSmiles=True)
    except Exception:
        return value.strip()


def representations_equal(kind: str, left: str, right: str) -> bool:
    if kind == "smiles":
        return normalize_smiles(left) == normalize_smiles(right)
    return normalize_formula(left) == normalize_formula(right)
