from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from typing import Any

from .builder import build_rows
from .io_utils import write_json, write_jsonl
from .registry import by_key, load_registry
from .runtime import run_case


ROOT = Path(__file__).resolve().parents[1]


SMOKE_PLAN = {
    "D0_none": {"attack_id": "A0_direct", "task_id": "C2_route_planning", "domain": "chemistry"},
    "AG_tool_filter": {"attack_id": "A4_task_injection", "task_id": "C2_route_planning", "domain": "chemistry"},
    "AG_pi_detector": {"attack_id": "A5_memory_poisoning", "task_id": "C3_memory_planning", "domain": "chemistry"},
    "AG_spotlighting": {"attack_id": "A4_task_injection", "task_id": "C2_route_planning", "domain": "chemistry"},
    "AG_repeat_query": {"attack_id": "A5_memory_poisoning", "task_id": "C3_memory_planning", "domain": "chemistry"},
    "CC_candidate_check": {"attack_id": "A0_direct", "task_id": "C1_screening", "domain": "chemistry"},
    "REG_known_hazard_lookup": {"attack_id": "A0_direct", "task_id": "C1_screening", "domain": "materials"},
}


def pick_pair(rows: list[dict[str, Any]], criteria: dict[str, str]) -> list[dict[str, Any]]:
    pair_id = None
    for row in rows:
        if row["case_kind"] != "attack":
            continue
        if any(row[key] != value for key, value in criteria.items()):
            continue
        pair_id = row["pair_id"]
        break
    if pair_id is None:
        raise ValueError(f"no smoke pair for {criteria}")
    pair = [row for row in rows if row["pair_id"] == pair_id]
    if len(pair) != 2:
        raise ValueError(f"bad pair {pair_id}: {len(pair)} rows")
    return sorted(pair, key=lambda row: row["case_kind"])


def _run_one(row: dict[str, Any], entry: Any, model: str, defense_id: str) -> dict[str, Any]:
    result = run_case(row, entry, model, defense_id=defense_id)
    return {
        "case_id": row["case_id"],
        "defense_id": defense_id,
        "summary": result.public_summary(),
        "final_answer": result.final_answer,
        "trajectory": result.trajectory,
        "defense_events": result.defense_state.events,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="gpt-5.1")
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--run-id")
    args = parser.parse_args()

    run_id = args.run_id or datetime.now().strftime("defense_smoke_%Y%m%d_%H%M%S")
    rows = build_rows()
    registry = by_key(load_registry())

    jobs = []
    for defense_id, criteria in SMOKE_PLAN.items():
        for row in pick_pair(rows, criteria):
            entry = registry[(row["hazard_class"], row["case_kind"])]
            jobs.append((defense_id, row, entry))

    records: list[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {
            pool.submit(_run_one, row, entry, args.model, defense_id): (defense_id, row["case_id"])
            for defense_id, row, entry in jobs
        }
        for future in as_completed(futures):
            defense_id, case_id = futures[future]
            try:
                record = future.result()
            except Exception as exc:
                record = {
                    "case_id": case_id,
                    "defense_id": defense_id,
                    "error": f"{type(exc).__name__}: {exc}",
                }
            records.append(record)
            print(f"completed {len(records)}/{len(jobs)} {defense_id} {case_id}", flush=True)

    records.sort(key=lambda value: (value["defense_id"], value["case_id"]))
    raw_path = ROOT / "private" / "audits" / f"{run_id}_{args.model}_raw.jsonl"
    write_jsonl(raw_path, records)

    summary_rows = []
    for record in records:
        if "summary" not in record:
            summary_rows.append(
                {
                    "case_id": record["case_id"],
                    "defense_id": record["defense_id"],
                    "error": record.get("error"),
                }
            )
            continue
        item = dict(record["summary"])
        item["defense_events"] = [
            event.get("kind")
            for event in record.get("defense_events", [])
        ]
        summary_rows.append(item)

    summary_path = ROOT / "runs" / f"{run_id}_{args.model}_summary.json"
    write_json(
        summary_path,
        {
            "run_id": run_id,
            "model": args.model,
            "n_jobs": len(jobs),
            "n_completed": sum("summary" in record for record in records),
            "n_errors": sum("summary" not in record for record in records),
            "raw_audit": str(raw_path),
            "smoke_plan": SMOKE_PLAN,
            "results": summary_rows,
        },
    )
    print(f"raw={raw_path}")
    print(f"summary={summary_path}")


if __name__ == "__main__":
    main()
