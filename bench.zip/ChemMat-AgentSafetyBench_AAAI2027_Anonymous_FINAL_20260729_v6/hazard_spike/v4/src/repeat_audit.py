﻿from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from typing import Any

from .builder import build_rows
from .io_utils import write_json, write_jsonl
from .registry import by_key, load_registry
from .runtime import run_case


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CASE_IDS = (
    "CMASB4-A-0008",
    "CMASB4-B-0008",
    "CMASB4-A-0013",
    "CMASB4-B-0013",
    "CMASB4-A-0017",
    "CMASB4-B-0017",
    "CMASB4-A-0058",
    "CMASB4-B-0058",
)


def _run_once(row: dict[str, Any], entry: Any, model: str, repeat: int) -> dict[str, Any]:
    result = run_case(row, entry, model)
    return {
        "case_id": row["case_id"],
        "repeat": repeat,
        "summary": result.public_summary(),
        "final_answer": result.final_answer,
        "trajectory": result.trajectory,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="gpt-5.1")
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--case-ids", default=",".join(DEFAULT_CASE_IDS))
    parser.add_argument("--run-id")
    args = parser.parse_args()

    run_id = args.run_id or datetime.now().strftime("repeat_audit_%Y%m%d_%H%M%S")
    case_ids = [value.strip() for value in args.case_ids.split(",") if value.strip()]
    rows_by_id = {row["case_id"]: row for row in build_rows()}
    missing = [case_id for case_id in case_ids if case_id not in rows_by_id]
    if missing:
        raise ValueError(f"Unknown case ids: {missing}")

    registry = by_key(load_registry())
    jobs = []
    for case_id in case_ids:
        row = rows_by_id[case_id]
        entry = registry[(row["hazard_class"], row["case_kind"])]
        for repeat in range(1, args.repeats + 1):
            jobs.append((row, entry, repeat))

    records: list[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {
            pool.submit(_run_once, row, entry, args.model, repeat): (row["case_id"], repeat)
            for row, entry, repeat in jobs
        }
        for future in as_completed(futures):
            case_id, repeat = futures[future]
            try:
                record = future.result()
            except Exception as exc:
                record = {
                    "case_id": case_id,
                    "repeat": repeat,
                    "error": f"{type(exc).__name__}: {exc}",
                }
            records.append(record)
            print(f"completed {len(records)}/{len(jobs)} {case_id} repeat={repeat}", flush=True)

    records.sort(key=lambda value: (value["case_id"], value["repeat"]))
    raw_path = ROOT / "private" / "audits" / f"{run_id}.jsonl"
    write_jsonl(raw_path, records)

    grouped: list[dict[str, Any]] = []
    for case_id in case_ids:
        case_records = [record for record in records if record["case_id"] == case_id]
        summaries = [record["summary"] for record in case_records if "summary" in record]
        row = rows_by_id[case_id]
        l3_applicable = row["task_id"] in {"C2_route_planning", "C3_memory_planning"}
        completed = len(summaries)
        utility_count = sum(
            bool(value["endpoint_complete"]) and not bool(value["refusal"])
            for value in summaries
        )
        grouped.append(
            {
                "case_id": case_id,
                "case_kind": row["case_kind"],
                "attack_id": row["attack_id"],
                "task_id": row["task_id"],
                "n_completed": completed,
                "n_errors": len(case_records) - len(summaries),
                "target_hit": sum(bool(value["target_hit"]) for value in summaries),
                "l3": sum(value["l3"] is True for value in summaries) if l3_applicable else None,
                "l3_applicable": l3_applicable,
                "utility": utility_count if row["case_kind"] == "benign" else None,
                "asr": sum(bool(value["asr"]) for value in summaries),
                "protocol_valid": sum(bool(value["protocol_valid"]) for value in summaries),
                "workflow_asr": sum(bool(value["workflow_asr"]) for value in summaries),
                "refusal": sum(bool(value["refusal"]) for value in summaries),
            }
        )

    summary_path = ROOT / "runs" / f"{run_id}_summary.json"
    write_json(
        summary_path,
        {
            "run_id": run_id,
            "model": args.model,
            "repeats": args.repeats,
            "n_jobs": len(jobs),
            "raw_audit": str(raw_path),
            "results": grouped,
        },
    )
    print(f"raw={raw_path}", flush=True)
    print(f"summary={summary_path}", flush=True)


if __name__ == "__main__":
    main()
