from __future__ import annotations

import argparse
import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path

from .spec import DEFENSES, VICTIM_MODELS


ROOT = Path(__file__).resolve().parents[1]


def slug(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", value).replace(".", "_")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--models", default=",".join(VICTIM_MODELS))
    parser.add_argument("--defenses", default=",".join(DEFENSES))
    parser.add_argument("--workers", type=int, default=64)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--run-prefix")
    parser.add_argument("--identity-stress", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    models = [model.strip() for model in args.models.split(",") if model.strip()]
    defenses = [defense.strip() for defense in args.defenses.split(",") if defense.strip()]
    unknown = [defense for defense in defenses if defense not in DEFENSES]
    if unknown:
        raise ValueError(f"unknown defenses: {unknown}")
    run_prefix = args.run_prefix or datetime.now().strftime("full_defense_%Y%m%d_%H%M%S")

    commands: list[tuple[str, str, list[str]]] = []
    for model in models:
        for defense_id in defenses:
            command = [
                sys.executable,
                "-m",
                "hazard_spike.v4.src.batch_eval",
                "--model",
                model,
                "--defense-id",
                defense_id,
                "--workers",
                str(args.workers),
                "--run-id",
                f"{run_prefix}_{slug(model)}_{defense_id}",
            ]
            if args.limit:
                command.extend(["--limit", str(args.limit)])
            if args.identity_stress:
                command.append("--identity-stress")
            commands.append((model, defense_id, command))

    if args.dry_run:
        for _, _, command in commands:
            print(" ".join(command))
        return

    failures: list[tuple[str, str, int]] = []
    for model, defense_id, command in commands:
        print(f"=== running model={model} defense={defense_id} ===", flush=True)
        completed = subprocess.run(command, cwd=ROOT.parents[1])
        if completed.returncode != 0:
            failures.append((model, defense_id, completed.returncode))
    if failures:
        raise SystemExit(f"failed runs: {failures}")


if __name__ == "__main__":
    main()
