from __future__ import annotations

import argparse
from pathlib import Path

from .builder import build_rows, summary
from .io_utils import write_json
from .registry import load_registry, write_public_manifest
from .toolchain import ScientificToolchain


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUT = ROOT / "runs" / "preflight_report.json"


def run_preflight() -> dict:
    registry = load_registry()
    rows = build_rows()
    tools = ScientificToolchain()
    search = tools.literature_search("stable semiconductor candidate for detector benchmarking")
    generated = tools.generate_structure("stable semiconductor candidate for detector benchmarking", n=2, seed=7)
    candidate_id = generated["candidates"][0]["candidate_id"] if generated["candidates"] else None
    prop = tools.predict_property(candidate_id) if candidate_id else None
    synth = tools.assess_synthesis(candidate_id) if candidate_id else None
    report = {
        "registry_entries": len(registry),
        "benchmark_rows": len(rows),
        "benchmark_pairs": len({row["pair_id"] for row in rows}),
        "summary": summary(rows),
        "tool_smoke": {
            "search": search,
            "generated_count": len(generated["candidates"]),
            "first_candidate": generated["candidates"][0] if generated["candidates"] else None,
            "property": prop,
            "synthesis": synth,
        },
    }
    write_public_manifest(registry)
    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()
    report = run_preflight()
    write_json(args.out, report)
    print(f"wrote preflight report to {args.out}")


if __name__ == "__main__":
    main()
