from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from typing import Any

from .builder import build_rows
from .io_utils import write_json, write_jsonl
from .registry import by_key, load_registry
from .runtime import run_case
from .spec import DEFENSE_APPLICABILITY, VICTIM_MODELS


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_RAW_DIR = ROOT / "private" / "audits"
DEFAULT_SUMMARY_DIR = ROOT / "runs"


def select_rows(
    rows: list[dict[str, Any]],
    *,
    limit: int | None,
    task_ids: set[str] | None,
    attack_ids: set[str] | None,
    case_ids: set[str] | None,
    defense_id: str,
) -> list[dict[str, Any]]:
    selected = []
    compatible_attacks = set(DEFENSE_APPLICABILITY[defense_id])
    for row in rows:
        if case_ids and row["case_id"] not in case_ids:
            continue
        if task_ids and row["task_id"] not in task_ids:
            continue
        if attack_ids and row["attack_id"] not in attack_ids:
            continue
        if row["attack_id"] not in compatible_attacks:
            continue
        selected.append(row)
        if limit and len(selected) >= limit:
            break
    return selected


def summarize(rows: list[dict[str, Any]]) -> dict[str, Any]:
    metrics = defaultdict(Counter)
    for row in rows:
        for key in ("task_id", "attack_id", "case_kind", "identity_surface"):
            metrics[key][row[key]] += 1
    return {key: dict(value) for key, value in metrics.items()}


def _run_one(row: dict[str, Any], entry: Any, model: str, defense_id: str) -> dict[str, Any]:
    result = run_case(row, entry, model, defense_id=defense_id)
    return {
        "case_id": row["case_id"],
        "summary": result.public_summary(),
        "final_answer": result.final_answer,
        "trajectory": result.trajectory,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default=VICTIM_MODELS[0])
    parser.add_argument("--defense-id", default="D0_none")
    parser.add_argument("--run-id")
    parser.add_argument("--raw-out", type=Path)
    parser.add_argument("--summary", type=Path)
    parser.add_argument("--workers", type=int, default=16)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--task-ids")
    parser.add_argument("--attack-ids")
    parser.add_argument("--case-ids")
    parser.add_argument("--identity-stress", action="store_true")
    args = parser.parse_args()
    if args.defense_id not in DEFENSE_APPLICABILITY:
        raise ValueError(f"unknown defense id: {args.defense_id}")

    run_id = args.run_id or datetime.now().strftime("batch_eval_%Y%m%d_%H%M%S")
    raw_out = args.raw_out or DEFAULT_RAW_DIR / f"{run_id}_{args.model}_{args.defense_id}_raw.jsonl"
    summary_out = args.summary or DEFAULT_SUMMARY_DIR / f"{run_id}_{args.model}_{args.defense_id}_summary.json"
    partial_summary_out = summary_out.with_name(summary_out.stem + "_partial.json")
    if raw_out.exists():
        raw_out.unlink()

    rows = build_rows(identity_stress=args.identity_stress)
    task_ids = set(args.task_ids.split(",")) if args.task_ids else None
    attack_ids = set(args.attack_ids.split(",")) if args.attack_ids else None
    case_ids = set(args.case_ids.split(",")) if args.case_ids else None
    selected = select_rows(
        rows,
        limit=args.limit,
        task_ids=task_ids,
        attack_ids=attack_ids,
        case_ids=case_ids,
        defense_id=args.defense_id,
    )
    registry = by_key(load_registry())

    records: list[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {}
        for row in selected:
            entry = registry[(row["hazard_class"], row["case_kind"])]
            futures[pool.submit(_run_one, row, entry, args.model, args.defense_id)] = row["case_id"]
        for future in as_completed(futures):
            case_id = futures[future]
            try:
                record = future.result()
            except Exception as exc:
                record = {
                    "case_id": case_id,
                    "error": f"{type(exc).__name__}: {exc}",
                }
            records.append(record)
            write_jsonl(raw_out, [record], mode="a")
            if len(records) % 20 == 0:
                output_rows = [item["summary"] for item in records if "summary" in item]
                write_json(
                    partial_summary_out,
                    {
                        "run_id": run_id,
                        "model": args.model,
                        "defense_id": args.defense_id,
                        "n_rows": len(selected),
                        "n_seen": len(records),
                        "n_completed": len(output_rows),
                        "n_errors": len(records) - len(output_rows),
                        "raw_audit": str(raw_out),
                        "selection": summarize(selected),
                        "identity_stress": args.identity_stress,
                    },
                )
            print(f"completed {len(records)}/{len(selected)} {case_id}", flush=True)

    records.sort(key=lambda value: value["case_id"])
    output_rows = [record["summary"] for record in records if "summary" in record]
    write_jsonl(raw_out, records)

    write_json(
        summary_out,
        {
            "run_id": run_id,
            "model": args.model,
            "defense_id": args.defense_id,
            "n_rows": len(selected),
            "n_completed": len(output_rows),
            "n_errors": len(records) - len(output_rows),
            "raw_audit": str(raw_out),
            "selection": summarize(selected),
            "identity_stress": args.identity_stress,
            "results": output_rows,
        },
    )
    print(f"raw={raw_out}")
    print(f"summary={summary_out}")


if __name__ == "__main__":
    main()
