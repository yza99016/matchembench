from __future__ import annotations

import argparse
import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path

from .spec import VICTIM_MODELS


ROOT = Path(__file__).resolve().parents[1]


def slug(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", value).replace(".", "_")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--models", default=",".join(VICTIM_MODELS))
    parser.add_argument("--workers", type=int, default=64)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--run-prefix")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    models = [model.strip() for model in args.models.split(",") if model.strip()]
    run_prefix = args.run_prefix or datetime.now().strftime("main_attack_%Y%m%d_%H%M%S")

    commands: list[list[str]] = []
    for model in models:
        command = [
            sys.executable,
            "-m",
            "hazard_spike.v4.src.batch_eval",
            "--model",
            model,
            "--workers",
            str(args.workers),
            "--run-id",
            f"{run_prefix}_{slug(model)}",
        ]
        if args.limit:
            command.extend(["--limit", str(args.limit)])
        commands.append(command)

    if args.dry_run:
        for command in commands:
            print(" ".join(command))
        return

    failures: list[tuple[str, int]] = []
    for model, command in zip(models, commands):
        print(f"=== running {model} ===", flush=True)
        completed = subprocess.run(command, cwd=ROOT.parents[1])
        if completed.returncode != 0:
            failures.append((model, completed.returncode))
    if failures:
        raise SystemExit(f"failed models: {failures}")


if __name__ == "__main__":
    main()
