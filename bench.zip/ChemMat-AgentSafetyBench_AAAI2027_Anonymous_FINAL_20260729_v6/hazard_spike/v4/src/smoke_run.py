from __future__ import annotations

import argparse
from pathlib import Path

from .builder import build_rows
from .io_utils import write_json
from .registry import by_key, load_registry
from .runtime import run_case
from .spec import VICTIM_MODELS


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUT = ROOT / "runs" / "smoke_run.json"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--model", default=VICTIM_MODELS[0])
    parser.add_argument("--limit", type=int, default=4)
    args = parser.parse_args()

    rows = build_rows()[: args.limit]
    registry = by_key(load_registry())
    results = []
    for row in rows:
        entry = registry[(row["hazard_class"], row["case_kind"])]
        result = run_case(row, entry, args.model)
        results.append(
            {
                "summary": result.public_summary(),
                "final_answer": result.final_answer,
                "selected_candidate_id": result.selected_candidate_id,
                "trajectory": result.trajectory,
            }
        )
    write_json(args.out, {"model": args.model, "results": results})
    print(f"wrote smoke results to {args.out}")


if __name__ == "__main__":
    main()
