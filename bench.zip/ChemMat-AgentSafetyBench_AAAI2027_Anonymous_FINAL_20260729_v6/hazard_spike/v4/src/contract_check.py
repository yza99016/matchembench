from __future__ import annotations

import argparse
from pathlib import Path

from .builder import build_rows
from .defense_smoke import SMOKE_PLAN
from .registry import by_key, load_registry
from .runtime import _normalized_text
from .spec import DEFENSE_APPLICABILITY
from .task_text import victim_task_text


ROOT = Path(__file__).resolve().parents[1]


def check_long_horizon_trusted_tasks() -> list[str]:
    errors: list[str] = []
    registry = by_key(load_registry())
    for row in build_rows():
        if row["case_kind"] != "attack" or row["attack_id"] == "A0_direct":
            continue
        attack_entry = registry[(row["hazard_class"], "attack")]
        benign_entry = registry[(row["hazard_class"], "benign_easy")]
        trusted_task = victim_task_text(row, benign_entry)
        if _normalized_text(attack_entry.display_label) in _normalized_text(trusted_task):
            errors.append(f"{row['case_id']} trusted task leaks attack target label")
        if attack_entry.representation and _normalized_text(attack_entry.representation) in _normalized_text(trusted_task):
            errors.append(f"{row['case_id']} trusted task leaks attack target representation")
    return errors


def check_candidate_boundary_smoke_plan() -> list[str]:
    errors: list[str] = []
    expected = {
        "CC_candidate_check": ("C1_screening", "chemistry"),
        "REG_known_hazard_lookup": ("C1_screening", "materials"),
    }
    for defense_id, (task_id, domain) in expected.items():
        plan = SMOKE_PLAN.get(defense_id)
        if not plan:
            errors.append(f"{defense_id} missing from smoke plan")
            continue
        if plan.get("task_id") != task_id or plan.get("domain") != domain:
            errors.append(f"{defense_id} smoke plan should use {task_id}/{domain}, got {plan}")
    return errors


def check_defense_applicability() -> list[str]:
    errors: list[str] = []
    attacks = {row["attack_id"] for row in build_rows()}
    for defense_id, applicable in DEFENSE_APPLICABILITY.items():
        missing = [attack for attack in applicable if attack not in attacks]
        if missing:
            errors.append(f"{defense_id} references unknown attacks: {missing}")
    return errors


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()
    checks = {
        "long_horizon_trusted_tasks": check_long_horizon_trusted_tasks(),
        "candidate_boundary_smoke_plan": check_candidate_boundary_smoke_plan(),
        "defense_applicability": check_defense_applicability(),
    }
    failed = {name: errors for name, errors in checks.items() if errors}
    if not args.quiet:
        for name, errors in checks.items():
            print(f"{name}: {'PASS' if not errors else 'FAIL'}")
            for error in errors:
                print(f"  - {error}")
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
