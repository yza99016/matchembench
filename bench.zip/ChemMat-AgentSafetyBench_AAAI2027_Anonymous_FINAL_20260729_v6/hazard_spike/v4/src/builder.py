from __future__ import annotations

import argparse
from collections import Counter
from pathlib import Path
from typing import Any

from .identity_surfaces import IDENTITY_SURFACES
from .io_utils import sha256_text, write_json, write_jsonl
from .registry import by_key, load_registry, write_public_manifest
from .spec import APPLICABLE_ATTACKS, CASE_KINDS, HAZARD_DOMAINS, SCENARIO_SHELLS, TASKS


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUT = ROOT / "runs" / "benchmark_v4.jsonl"
DEFAULT_SUMMARY = ROOT / "runs" / "benchmark_v4_summary.json"


SCENARIO_TEXT = {
    "application": "an application-oriented discovery request",
    "screening": "a candidate screening and comparison request",
    "process_or_device": "a process or device-oriented research request",
}


def build_rows(*, identity_stress: bool = False) -> list[dict[str, Any]]:
    entries = load_registry()
    registry = by_key(entries)
    rows: list[dict[str, Any]] = []
    index = 0
    surfaces = IDENTITY_SURFACES if identity_stress else ("S0_canonical",)
    for hazard_class, domain in HAZARD_DOMAINS.items():
        for shell in SCENARIO_SHELLS:
            for task_id, task in TASKS.items():
                for attack_id in APPLICABLE_ATTACKS[task_id]:
                    for surface in surfaces:
                        pair_id = f"CMASB4-P-{index:04d}"
                        for case_kind in CASE_KINDS:
                            entry = registry[(hazard_class, case_kind)]
                            case_prefix = {
                                "attack": "A",
                                "benign_easy": "E",
                                "benign_hard": "H",
                                "benign_close": "N",
                            }[case_kind]
                            case_id = f"CMASB4-{case_prefix}-{index:04d}"
                            public_goal = {
                                "domain": domain,
                                "scenario": SCENARIO_TEXT[shell],
                                "task_endpoint": task["endpoint"],
                                "case_kind": case_kind,
                                "identity_surface": surface,
                            }
                            rows.append({
                                "schema_version": "4.0-identity-stress" if identity_stress else "4.0",
                                "case_id": case_id,
                                "pair_id": pair_id,
                                "case_kind": case_kind,
                                "hazard_class": hazard_class,
                                "domain": domain,
                                "scenario_shell": shell,
                                "task_id": task_id,
                                "attack_id": attack_id,
                                "identity_surface": surface,
                                "horizon": "short" if attack_id == "A0_direct" else "long",
                                "allowed_tools": list(task["tools"]),
                                "memory_enabled": bool(task["memory"]),
                                "endpoint": task["endpoint"],
                                "registry_entry_id": entry.entry_id,
                                "target_commitment": entry.representation_hash,
                                "public_goal": public_goal,
                                "public_goal_hash": sha256_text(str(sorted(public_goal.items()))),
                            })
                        index += 1
    expected = 1728 * len(surfaces)
    if len(rows) != expected:
        raise AssertionError(f"expected {expected} rows, got {len(rows)}")
    return rows


def summary(rows: list[dict[str, Any]]) -> dict[str, Any]:
    keys = ["case_kind", "hazard_class", "domain", "scenario_shell", "task_id", "attack_id", "identity_surface", "horizon"]
    counts = {key: dict(Counter(row[key] for row in rows)) for key in keys}
    n_surfaces = len(counts.get("identity_surface", {}))
    return {
        "schema_version": "4.0-benchmark-summary",
        "n_rows": len(rows),
        "n_pairs": len({row["pair_id"] for row in rows}),
        "formula": (
            "8 target classes x 3 scenario shells x (3+4+5+6 task-attack cells) "
            f"x {n_surfaces} identity surfaces x 4 case kinds = {len(rows)}"
        ),
        "counts": counts,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--summary", type=Path, default=DEFAULT_SUMMARY)
    parser.add_argument("--identity-stress", action="store_true")
    args = parser.parse_args()
    rows = build_rows(identity_stress=args.identity_stress)
    write_jsonl(args.out, rows)
    write_json(args.summary, summary(rows))
    write_public_manifest(load_registry())
    print(f"wrote {len(rows)} rows to {args.out}")


if __name__ == "__main__":
    main()
