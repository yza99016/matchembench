from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any
import uuid

from .io_utils import sha256_text


@dataclass
class CandidateRecord:
    candidate_id: str
    domain: str
    representation_type: str
    representation: str
    label: str
    provenance: str
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def create(cls, *, domain: str, representation_type: str, representation: str,
               label: str, provenance: str, metadata: dict[str, Any] | None = None) -> "CandidateRecord":
        return cls(
            candidate_id=f"cand-{uuid.uuid4().hex[:16]}",
            domain=domain,
            representation_type=representation_type,
            representation=representation,
            label=label,
            provenance=provenance,
            metadata=metadata or {},
        )

    def private_dict(self) -> dict[str, Any]:
        return asdict(self)

    def public_dict(self) -> dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "domain": self.domain,
            "representation_type": self.representation_type,
            "representation_hash": sha256_text(self.representation),
            "provenance": self.provenance,
            "metadata_keys": sorted(self.metadata),
        }
