"""Version 4 benchmark implementation."""
