"""OpenAI-compatible model transport used by the benchmark.

Credentials are read from environment variables. A local ``.env`` file is
supported for convenience but is never required and must not be committed.
"""
import json
import os
import time
from pathlib import Path
import urllib.request
import urllib.error

HERE = Path(__file__).parent

def load_env():
    env = {}
    env_path = Path(os.environ.get("CHEMMAT_ENV_FILE", HERE / ".env"))
    if env_path.is_file():
        with env_path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, value = line.split("=", 1)
                env[key.strip()] = value.strip()
    for key in ("DMX_API_KEY", "DMX_BASE_URL", "MP_API_KEY"):
        if os.environ.get(key):
            env[key] = os.environ[key]
    return env

def _call_once(api_key, base_url, model, messages, max_tokens, temperature, timeout):
    """Single attempt at the chat-completions endpoint.
    2026-06-02 fix: DMX 平台 claude-opus-4-7 弃用 temperature 参数 (ValidationException)。
    对 opus-4-7 / claude opus 系列不传 temperature。
    """
    url = base_url.rstrip("/") + "/chat/completions"
    body = {
        "model": model,
        "messages": list(messages),
        "max_tokens": max_tokens,
    }
    # 仅对未弃用 temperature 的模型传该参数
    if "opus-4-7" not in model and "opus-4-5" not in model:
        body["temperature"] = temperature
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
        dt = time.time() - t0
        msg = payload.get("choices", [{}])[0].get("message", {})
        content = msg.get("content", "")
        if not content:
            content = msg.get("reasoning_content", "")
        usage = payload.get("usage", {})
        if not content or not str(content).strip():
            return {"ok": False, "error": "empty_content", "elapsed": dt, "_retryable": True}
        return {"ok": True, "content": content, "usage": usage, "elapsed": dt}
    except urllib.error.HTTPError as e:
        body_text = e.read().decode("utf-8", errors="replace") if e.fp else ""
        retryable = e.code in (408, 429, 500, 502, 503, 504)
        return {"ok": False, "error": f"HTTP {e.code}: {body_text[:500]}",
                "elapsed": time.time() - t0, "_retryable": retryable}
    except Exception as e:
        # Network/timeout errors are retryable; others typically aren't
        retryable = isinstance(e, (urllib.error.URLError, TimeoutError, ConnectionError))
        return {"ok": False, "error": f"{type(e).__name__}: {e}",
                "elapsed": time.time() - t0, "_retryable": retryable}


def call_model_messages(api_key: str, base_url: str, model: str, messages: list,
                        max_tokens: int = 1500, temperature: float = 0.3,
                        timeout: int = 180, max_retries: int = 3,
                        retry_backoff: float = 1.5):
    """Call chat-completions with automatic retry on transient failures.

    Retries on: HTTP 408/429/5xx, timeouts, connection errors, empty content.
    Does NOT retry on: HTTP 4xx (except 408/429), JSON parse errors.
    """
    last = None
    for attempt in range(max_retries + 1):
        res = _call_once(api_key, base_url, model, messages, max_tokens, temperature, timeout)
        if res.get("ok"):
            if attempt > 0:
                res["retries"] = attempt
            return res
        last = res
        if not res.get("_retryable", False):
            break  # non-retryable error
        if attempt >= max_retries:
            break
        time.sleep(retry_backoff * (2 ** attempt))  # 1.5, 3, 6 seconds
    if last is not None:
        last.pop("_retryable", None)
        if max_retries > 0:
            last["retries"] = max_retries
    return last or {"ok": False, "error": "no_attempts"}


def call_model(api_key: str, base_url: str, model: str, prompt: str,
               max_tokens: int = 1500, temperature: float = 0.3, timeout: int = 180):
    """Single-prompt convenience wrapper."""
    return call_model_messages(api_key, base_url, model,
                               [{"role": "user", "content": prompt}],
                               max_tokens=max_tokens, temperature=temperature, timeout=timeout)


def build_prompt(persona_prefix: str, case: dict) -> str:
    return persona_prefix + case["research_question"]


def run_matrix(models, cases_path, out_path, max_tokens=1500):
    env = load_env()
    api_key = env["DMX_API_KEY"]
    base_url = env["DMX_BASE_URL"]

    with open(cases_path, "r", encoding="utf-8") as f:
        spec = json.load(f)
    cases = spec["cases"]
    personas = spec["personas"]

    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    total = len(models) * len(cases) * len(personas)
    done = 0
    with open(out_path, "w", encoding="utf-8") as fout:
        for case in cases:
            for persona in personas:
                prompt = build_prompt(persona["prefix"], case)
                for model in models:
                    done += 1
                    print(f"[{done}/{total}] {case['id']} | {persona['id']} | {model}", flush=True)
                    res = call_model(api_key, base_url, model, prompt, max_tokens=max_tokens)
                    rec = {
                        "case_id": case["id"],
                        "persona_id": persona["id"],
                        "model": model,
                        "prompt": prompt,
                        "result": res,
                    }
                    fout.write(json.dumps(rec, ensure_ascii=False) + "\n")
                    fout.flush()
                    if not res.get("ok"):
                        print(f"  ! FAIL: {res.get('error')}", flush=True)
                    else:
                        print(f"  ok ({res.get('elapsed', 0):.1f}s, {len(res.get('content',''))} chars)", flush=True)
    print(f"\nWrote {out_path}")


if __name__ == "__main__":
    import sys
    mode = sys.argv[1] if len(sys.argv) > 1 else "smoke"

    if mode == "smoke":
        # 1 case, 1 persona, 1 model — sanity check
        models = ["gpt-4o"]
        env = load_env()
        spec = json.load(open(HERE / "cases.json", "r", encoding="utf-8"))
        case = spec["cases"][0]
        persona = spec["personas"][0]
        prompt = build_prompt(persona["prefix"], case)
        print(f"SMOKE: {case['id']} | {persona['id']} | {models[0]}")
        print("PROMPT:", prompt[:200])
        res = call_model(env["DMX_API_KEY"], env["DMX_BASE_URL"], models[0], prompt, max_tokens=800)
        print("RESULT ok=", res.get("ok"), "elapsed=", round(res.get("elapsed", 0), 1))
        if res.get("ok"):
            print("CONTENT[:600]:", res["content"][:600])
        else:
            print("ERROR:", res.get("error"))

    elif mode == "full":
        models = ["gpt-4o", "claude-sonnet-4-6-thinking", "deepseek-r1"]
        run_matrix(models, HERE / "cases.json", HERE / "runs" / "matrix.jsonl", max_tokens=1500)

    else:
        print("usage: python harness.py [smoke|full]")
