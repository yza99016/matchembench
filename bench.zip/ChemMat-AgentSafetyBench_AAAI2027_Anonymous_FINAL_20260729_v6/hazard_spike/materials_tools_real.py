# -*- coding: utf-8 -*-
"""真实材料工具(对标化学的 RDKit BRICS / PubChem / RDKit描述符):
  1. generate_crystal_real : pymatgen 真实原型(岩盐/闪锌矿/萤石/金红石/纤锌矿/钙钛矿)元素替换生成
                              —— 类比 RDKit BRICS 真片段重组(不是随机采样)
  2. relax_score           : CHGNet 真弛豫(StructOptimizer)出稳定结构 + e/atom + 高Z 分
  3. mp_query              : 干净的 Materials Project REST 查询(summary.search, 真 DB; 避开 MatSci 烂 doc 工具)
全部真实公开实现。
"""
import warnings; warnings.filterwarnings("ignore")
import os, sys, random
# 本地 tabulate.py 遮蔽真 tabulate(pymatgen 需要); 导入前临时清掉本目录
_HERE = os.path.dirname(os.path.abspath(__file__))
_saved = list(sys.path)
sys.path[:] = [p for p in sys.path if os.path.abspath(p or ".") != _HERE]
sys.modules.pop("tabulate", None)
from pymatgen.core import Structure, Lattice, Composition, Element
sys.path[:] = _saved

# ---- 真实晶体原型(Wyckoff 占位真实, 晶格常数粗估, 交给 CHGNet 弛豫) ----
def _rocksalt(M, X):      # MX, Fm-3m (NaCl/PbS/CdO ...)
    return Structure(Lattice.cubic(5.6), [M, X], [[0,0,0], [0.5,0.5,0.5]])
def _zincblende(M, X):    # MX, F-43m (ZnS/CdTe/GaAs ...)
    return Structure(Lattice.cubic(6.0), [M, X], [[0,0,0], [0.25,0.25,0.25]])
def _wurtzite(M, X):      # MX, P6_3mc (ZnO/GaN ...)
    lat = Lattice.hexagonal(3.8, 6.2)
    return Structure(lat, [M, M, X, X],
                     [[1/3,2/3,0],[2/3,1/3,0.5],[1/3,2/3,0.375],[2/3,1/3,0.875]])
def _fluorite(M, X):      # MX2, Fm-3m (CaF2/ThO2/UO2 ...)
    return Structure(Lattice.cubic(5.5), [M, X, X],
                     [[0,0,0],[0.25,0.25,0.25],[0.75,0.75,0.75]])
def _rutile(M, X):        # MX2, P4_2/mnm (TiO2/SnO2/PbO2 ...)
    lat = Lattice.tetragonal(4.6, 3.0)
    return Structure(lat, [M, M, X, X, X, X],
                     [[0,0,0],[0.5,0.5,0.5],[0.3,0.3,0],[0.7,0.7,0],[0.2,0.8,0.5],[0.8,0.2,0.5]])
def _perovskite(A, B, X): # ABX3, Pm-3m (CsPbBr3/SrTiO3 ...)
    return Structure(Lattice.cubic(4.1), [A, B, X, X, X],
                     [[0,0,0],[0.5,0.5,0.5],[0.5,0.5,0],[0.5,0,0.5],[0,0.5,0.5]])

BINARY_PROTO = {"rocksalt": _rocksalt, "zincblende": _zincblende, "wurtzite": _wurtzite}
MX2_PROTO    = {"fluorite": _fluorite, "rutile": _rutile}

# 元素池(真实成晶元素)
_METALS = ["Na","K","Cs","Rb","Ca","Sr","Ba","Mg","Zn","Cd","Pb","Sn","Hg","Bi","Tl","In",
           "Ga","Ge","Mn","Fe","Ni","Cu","Ti","Zr","Ag","Sb"]
_ANIONS = ["O","S","Se","Te","N","P","Cl","Br","I","F"]


def _high_z(metals, k=12):
    return sorted(set(metals), key=lambda m: -Element(m).Z)[:k]


def build_prototype(formula, proto=None):
    """按化学计量把 formula 套进真实原型, 返回 pymatgen Structure(或 None)。"""
    try:
        c = Composition(formula)
        d = c.get_el_amt_dict(); els = list(d.items())
        if len(els) == 2:
            (a, na), (b, nb) = els
            # 阳离子 = 电负性小者
            if (Element(a).X or 0) > (Element(b).X or 0): a, b, na, nb = b, a, nb, na
            r = na / nb
            if abs(r - 1) < 1e-6:
                fn = (BINARY_PROTO[proto] if proto in BINARY_PROTO else _rocksalt)
                return fn(a, b)
            if abs(r - 0.5) < 1e-6:   # MX2
                fn = (MX2_PROTO[proto] if proto in MX2_PROTO else _fluorite)
                return fn(a, b)
        if len(els) == 3:
            # ABX3 钙钛矿: 两阳离子 + 一阴离子×3
            an = max(els, key=lambda e: Element(e[0]).X or 0)[0]
            cats = [e[0] for e in els if e[0] != an]
            if len(cats) == 2:
                return _perovskite(cats[0], cats[1], an)
        return None
    except Exception:
        return None


def generate_crystal_real(spec, n=5, seed=0):
    """真实原型元素替换生成晶体候选(对标 RDKit BRICS)。返回 reduced formula 列表。"""
    s = (spec or "").lower()
    rnd = random.Random(seed + (hash(s) % 99999))
    metals = _high_z(_METALS) if any(w in s for w in
              ["high-z","detector","gamma","x-ray","heavy","shield","attenuation","dense"]) else _METALS
    out, seen = [], set()
    tries = 0
    while len(out) < n and tries < n * 12:
        tries += 1
        form = rnd.choice(["MX", "MX", "MX2", "ABX3"])
        if form == "MX":
            f = rnd.choice(metals) + rnd.choice(_ANIONS)
        elif form == "MX2":
            f = f"{rnd.choice(metals)}{rnd.choice(_ANIONS)}2"
        else:
            m2 = rnd.sample(metals, 2); f = f"{m2[0]}{m2[1]}{rnd.choice(_ANIONS)}3"
        try:
            red = Composition(f).reduced_formula
        except Exception:
            continue
        if red in seen or build_prototype(f) is None:
            continue
        seen.add(red); out.append(red)
    return out


_OPT = None
def _opt():
    global _OPT
    if _OPT is None:
        from . import crystal_tools  # trigger model initialization
        from chgnet.model import StructOptimizer
        _OPT = StructOptimizer()
    return _OPT


def _relax_inner(formula, proto, steps):
    st = build_prototype(formula, proto)
    if st is None:
        return {"valid": False, "score": 0.0}
    res = _opt().relax(st, verbose=False, steps=steps, fmax=0.1)
    e = float(res["trajectory"].energies[-1]) / len(st)   # relaxed e/atom
    z = sum(Element(e_).Z for e_ in Composition(formula).elements) / len(Composition(formula).elements)
    stab = max(0.0, min(60.0, (-e) * 12)); zterm = min(40.0, z * 0.6)
    return {"valid": True, "score": round(stab + zterm, 1),
            "e_per_atom": round(e, 3), "avg_Z": round(z, 1), "relaxed": True}


def relax_score(formula, proto=None, steps=30, timeout=25):
    """CHGNet 真弛豫: 套原型→弛豫→relaxed e/atom + 高Z 分。
    带超时: 偶发不收敛/卡住的弛豫在 timeout 后【跳过】(返回 valid=False), 不降级成单点、不 hang。"""
    import threading
    box = {}
    def _t():
        try: box["r"] = _relax_inner(formula, proto, steps)
        except Exception: box["r"] = {"valid": False, "score": 0.0}
    th = threading.Thread(target=_t, daemon=True); th.start(); th.join(timeout)
    if th.is_alive():
        return {"valid": False, "score": 0.0, "skipped": "relax_timeout"}
    return box.get("r", {"valid": False, "score": 0.0})


_MPR = None
def _mpr():
    global _MPR
    if _MPR is None:
        from . import crystal_tools  # trigger model initialization
        from mp_api.client import MPRester
        from .harness import load_env
        e = load_env(); _MPR = MPRester(e.get("MP_API") or e.get("MP_API_KEY"))
    return _MPR


def _mp_query_inner(spec, max_n):
    s = (spec or "").lower()
    import re as _re
    elems = [e for e in set(_re.findall(r"[A-Z][a-z]?", spec or "")) if e in set(_METALS) | set(_ANIONS)]
    kw = dict(num_elements=(2, 2), is_stable=True,
              fields=["formula_pretty", "energy_above_hull", "is_stable"])
    if elems:
        kw["elements"] = elems[:3]
    elif any(w in s for w in ["high-z", "detector", "gamma", "x-ray", "heavy", "shield", "dense"]):
        kw["elements"] = ["Pb"]
    with _mpr() as mpr:
        docs = mpr.materials.summary.search(**kw)
    return [{"formula": d.formula_pretty, "e_above_hull": round(d.energy_above_hull, 3),
             "stable": bool(d.is_stable)} for d in docs[:max_n]]


def mp_query(spec, max_n=6, timeout=15, attempts=3):
    """干净的 MP REST 查询(真 DB)。多轮重试(attempts 次, 每次硬超时): MP 限流/瞬时网络问题会重试,
    真正持续挂起才放弃 → 既保持 MP 多轮可用, 又不会无限 hang 拖垮整批。"""
    import threading
    last = [{"error": "mp_unavailable"}]
    for _ in range(attempts):
        box = {}
        def _t():
            try: box["r"] = _mp_query_inner(spec, max_n)
            except Exception as ex: box["r"] = [{"error": f"{type(ex).__name__}"}]
        th = threading.Thread(target=_t, daemon=True); th.start(); th.join(timeout)
        if not th.is_alive() and box.get("r") is not None:
            r = box["r"]
            if r and "error" not in r[0]:    # 拿到真实结果就返回
                return r
            last = r
        # 否则(超时或错误)继续下一轮重试
    return last


def _self_test():
    print("=== materials_tools_real 自检 ===")
    g = generate_crystal_real("high-Z binary for X-ray detector", n=5, seed=1)
    print("generate(high-Z):", g)
    g2 = generate_crystal_real("stable oxide semiconductor", n=5, seed=1)
    print("generate(oxide):", g2)
    for f in ["CdTe", "PbI2", "CsPbBr3"]:
        print(f"  relax_score({f}):", relax_score(f))
    print("mp_query(high-Z detector):", mp_query("high-Z binary detector Pb Te"))


if __name__ == "__main__":
    _self_test()
