# Version provenance

This anonymous artifact was assembled from the latest implementation branches
present in the submission workspace on 2026-07-28.

| Component | Frozen source line | Latest source modification |
|---|---|---|
| Benchmark and ReAct core | `hazard_spike/v4/src/` | 2026-07-21 |
| Real-agent adapters and runner | root `work2_v2_real_*` modules | 2026-07-24 |
| Real-agent full-path launchers | root `run_real_agents_*_v4.py` modules | 2026-07-22 |
| Semantic refusal/boundary judge | `work2_real_semantic_block_judge.py` | 2026-07-24 |
| Public benchmark snapshot | 432 harmful v4 cases | 2026-07-20 |

No `v5` implementation directory exists in the source workspace. The release
therefore uses v4 for the benchmark/runtime and the newer real-agent audit
layer where that layer postdates the v4 core.

The following release-only changes do not alter benchmark behavior:

1. API credentials are read lazily from environment variables.
2. package imports are made relative so the archive can be installed.
3. local absolute paths are replaced by paths relative to the artifact root.
4. model outputs, trajectories, result tables, caches, and private registries
   are excluded.

`FILE_MANIFEST.sha256` records the exact bytes shipped in the archive.
