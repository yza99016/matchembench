# Reproducibility checklist

1. Create a clean Python 3.10/3.11 environment.
2. Run `pip install -e .`.
3. Run `python scripts/verify_release.py`.
4. Install `requirements-science.txt` only when scientific backends are used.
5. Configure model and Materials Project credentials through environment
   variables.
6. Supply the authorized private registry without modifying public case IDs.
7. Run `run_main_attack --dry-run` or `run_full_defense --dry-run` before any
   paid execution.
8. Keep raw trajectories and result summaries outside the release archive.

The artifact does not contain reported experimental outputs. This is
intentional: the submission package provides the implementation and static
benchmark while excluding raw data and results at the authors' release
boundary.

