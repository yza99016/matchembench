# Real-agent transfer setup

The transfer runner preserves each upstream agent's native entry point and
adapts only the model transport. Upstream projects are not redistributed in
this archive. Check out the pinned revisions under `real_agents/`:

| Adapter | Expected path | Upstream repository | Pinned revision |
|---|---|---|---|
| ChemGraph single/multi | `real_agents/vendor_external/ChemGraph` | `https://github.com/argonne-lcf/ChemGraph.git` | `e9e83bccacee05ae123e4dcf989e4e9e9b2dfa08` |
| SKY synthesis | `real_agents/vendor_external/synthesis-agent` | `https://github.com/hspark1212/synthesis-agent.git` | `672a67db6df8652a5855ebe5f5600cce230f2077` |
| CACTUS | `real_agents/vendor_external/cactus` | `https://github.com/pnnl/cactus.git` | `21846395564ce143a3162591263602c57ec2ddaf` |
| ChemToolAgent | `real_agents/vendor/chemtoolagent` | official ChemToolAgent release associated with arXiv:2411.07228 | upstream snapshot |

Example checkout:

```bash
git clone https://github.com/argonne-lcf/ChemGraph.git real_agents/vendor_external/ChemGraph
git -C real_agents/vendor_external/ChemGraph checkout e9e83bccacee05ae123e4dcf989e4e9e9b2dfa08

git clone https://github.com/hspark1212/synthesis-agent.git real_agents/vendor_external/synthesis-agent
git -C real_agents/vendor_external/synthesis-agent checkout 672a67db6df8652a5855ebe5f5600cce230f2077

git clone https://github.com/pnnl/cactus.git real_agents/vendor_external/cactus
git -C real_agents/vendor_external/cactus checkout 21846395564ce143a3162591263602c57ec2ddaf
```

Use separate virtual environments because the upstream projects have
incompatible dependency ranges. The runner looks for:

```text
real_agents/venv_materials
real_agents/venv_sky
real_agents/venv_cactus
```

Install each upstream project according to its own pinned README or lock file.
For example:

```bash
python -m venv real_agents/venv_cactus
real_agents/venv_cactus/bin/pip install -e real_agents/vendor_external/cactus
```

On Windows, replace `bin/pip` with `Scripts/pip.exe`.

The public archive does not include the private materialized task prompts or
model outputs used by the transfer study. The adapters and capability mapping
are included for implementation review. An authorized rerun requires the same
controlled target registry and task materialization process as the primary
runtime.

## Entry points

The current full-path transfer layer consists of:

| Module | Role |
|---|---|
| `run_real_agents_attack_v4.py` | legacy private-task launcher retained for implementation review |
| `run_real_agents_benign_path_v4.py` | matched benign full-path launcher |
| `subprocess_runner_materials.py` | isolated upstream-agent dispatcher |
| `work2_real_semantic_block_judge.py` | semantic classification of safety refusal, task boundary, incomplete output, and runtime failure |
| `work2_v2_real_agent_runner.py` | stateful native-session transfer runner |
| `work2_v2_real_session_worker.py` | per-session worker used by the stateful runner |

The following public inspection commands run without private task material:

```bash
python -m real_agents.run_real_agents_attack_v4 --help
python -m real_agents.run_real_agents_attack_v4 --check-setup
python -m real_agents.run_real_agents_benign_path_v4 --help
python -m real_agents.work2_real_semantic_block_judge --help
python -m real_agents.work2_v2_real_agent_runner --help
```

The legacy attack launcher cannot execute the transfer study from the public
archive because its materialized attack prompts are deliberately excluded.
Use the current plan-based runner for an authorized rerun after supplying the
controlled plan and target registry.

For an authorized materialized case plan on Windows:

```powershell
$env:REAL_AGENT_PLAN="private\real_agent_plan.jsonl"
$env:REAL_AGENT_OUTPUT="outputs\real_agents"
.\scripts\run_real_agent_plan.ps1
```

Raw responses and semantic judgments are written only to local run directories.
They are intentionally absent from this archive and must remain uncommitted.
The semantic judge defaults to `qwen3.5-397b-a17b`; override it only by editing
the run configuration under an authorized evaluation protocol.
