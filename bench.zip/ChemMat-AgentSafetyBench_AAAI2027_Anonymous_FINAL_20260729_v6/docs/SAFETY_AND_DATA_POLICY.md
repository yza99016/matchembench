# Safety and data-release policy

This anonymous artifact separates public benchmark metadata from
access-controlled evaluation material.

## Included

- source code and configuration;
- 432 harmful case specifications with opaque target commitments;
- three 432-case benign-control splits;
- attack/defense applicability metadata;
- offline integrity checks.

## Excluded

- concrete hazardous target identities and private registry representations;
- verbatim attack prompts generated during online rollouts;
- raw victim, attacker, or judge outputs;
- tool observations containing concrete candidates;
- experiment summaries, tables, scores, logs, caches, or checkpoints;
- API keys, service tokens, account identifiers, author names, email
  addresses, institutional addresses, private IP addresses, SSH information,
  and absolute local paths.

The online runtime expects the controlled registry at
`hazard_spike/v4/private/candidate_registry.json`. Its schema is validated by
`hazard_spike.v4.src.registry`. It is intentionally absent from this archive.
Authorized evaluators can supply it without changing the public case IDs or
hash commitments.

Generated runs should be written outside the source tree or under ignored
`outputs/`, `private/`, and `runs/` directories. Do not publish those files
without a separate content and privacy review.

