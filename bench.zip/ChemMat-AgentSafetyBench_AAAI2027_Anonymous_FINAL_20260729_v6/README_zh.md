# ChemMat-AgentSafetyBench 匿名提交包

本压缩包包含论文使用的最新 v4 主程序、432 条危险静态 benchmark、通用与领域防御、语义裁决代码，以及真实 agent 接入与启动脚本。包内不包含模型原文、运行轨迹、实验结果、密钥、作者信息或本机路径。

## 数据规模

- `benchmark/benchmark_v4.jsonl`：论文报告的 432 条危险静态 case specification。
- `benchmark/splits/attack.jsonl`：同一数据的便捷入口。
- 432 的构造为 `8 类危害 × 3 类场景壳 × (3+4+5+6 个有效任务-攻击单元)`。
- 真实 agent 的无害任务仅用于迁移实验中的能力参照，由运行脚本生成，不计入静态 benchmark。

模型数量、防御数量、在线 rollout 次数和真实 agent 数量都是实验条件，不计入 benchmark 数量。

## 安装

建议使用 Python 3.10 或 3.11：

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -e .
python scripts/verify_release.py
```

运行 RDKit、pymatgen、CHGNet 和 Materials Project 后端时，再安装：

```powershell
pip install -r requirements-science.txt
```

在线模型通过环境变量配置。不要把真实密钥写入源码：

```powershell
$env:DMX_API_KEY="YOUR_API_KEY"
$env:DMX_BASE_URL="https://YOUR_OPENAI_COMPATIBLE_ENDPOINT/v1"
$env:MP_API_KEY="YOUR_OPTIONAL_MATERIALS_PROJECT_KEY"
```

## 启动

离线检查发布边界和 benchmark：

```powershell
python scripts/verify_release.py
```

预览主攻击与防御命令，不调用 API：

```powershell
python -m hazard_spike.v4.src.run_main_attack --dry-run
python -m hazard_spike.v4.src.run_full_defense --dry-run
```

完整在线评测需要经授权的私有目标注册表，放在 `hazard_spike/v4/private/candidate_registry.json`。该注册表以及模型原文、轨迹和结果均不属于匿名公开包。

真实 agent 的上游仓库、隔离环境和启动方式见 `docs/REAL_AGENT_SETUP.md`。版本核对结果见 `docs/VERSION_PROVENANCE.md`：核心 v4 最后更新于 2026-07-21，真实 agent 与语义审计层最后更新于 2026-07-24，源工作区不存在 v5。
