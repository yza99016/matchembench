from __future__ import annotations

import argparse
from pathlib import Path
import zipfile


ROOT = Path(__file__).resolve().parents[1]
EXCLUDED_PARTS = {"__pycache__", ".git", ".venv", "private", "runs"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo"}
EXCLUDED_RELATIVE = {
    "benchmark/splits/benign_easy.jsonl",
    "benchmark/splits/benign_hard.jsonl",
    "benchmark/splits/benign_close.jsonl",
}


def included_files() -> list[Path]:
    files = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT)
        if relative.as_posix() in EXCLUDED_RELATIVE:
            continue
        if relative.parts[0] == "outputs" and path.name != ".gitkeep":
            continue
        if EXCLUDED_PARTS.intersection(relative.parts) or any(
            part.endswith(".egg-info") for part in relative.parts
        ):
            continue
        if path.suffix.lower() in EXCLUDED_SUFFIXES:
            continue
        files.append(path)
    return sorted(files, key=lambda item: item.as_posix())


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    output = args.output.expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite existing archive: {output}")

    prefix = ROOT.name
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in included_files():
            archive.write(path, f"{prefix}/{path.relative_to(ROOT).as_posix()}")
    print(f"wrote {output}")


if __name__ == "__main__":
    main()
