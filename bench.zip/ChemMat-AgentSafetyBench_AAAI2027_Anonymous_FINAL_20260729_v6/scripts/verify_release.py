from __future__ import annotations

from collections import Counter
import json
from pathlib import Path
import re
import sys


ROOT = Path(__file__).resolve().parents[1]
BENCHMARK = ROOT / "benchmark" / "benchmark_v4.jsonl"
ATTACK_SPLIT = ROOT / "benchmark" / "splits" / "attack.jsonl"
REQUIRED_PATHS = (
    "README.md",
    "README_zh.md",
    "pyproject.toml",
    "requirements-defense.txt",
    "requirements-science.txt",
    "benchmark/benchmark_v4.jsonl",
    "benchmark/benchmark_v4_summary.json",
    "benchmark/defense_applicability.json",
    "benchmark/splits/attack.jsonl",
    "docs/REAL_AGENT_SETUP.md",
    "hazard_spike/harness.py",
    "hazard_spike/v4/src/run_main_attack.py",
    "hazard_spike/v4/src/run_full_defense.py",
    "real_agents/__init__.py",
    "real_agents/work2_v2_real_agent_runner.py",
    "real_agents/work2_real_semantic_block_judge.py",
    "scripts/build_file_manifest.py",
    "scripts/build_zip.py",
    "scripts/verify_release.py",
)

FORBIDDEN_NAMES = re.compile(
    r"(?:^|[._-])(raw|result|results|summary_partial|log|cache|checkpoint|"
    r"private_runs?)(?:[._-]|$)",
    re.IGNORECASE,
)
SECRET_PATTERNS = {
    "api_key": re.compile(r"\bsk-[A-Za-z0-9_-]{12,}\b"),
    "private_ip": re.compile(
        r"\b(?:10(?:\.\d{1,3}){3}|172\.(?:1[6-9]|2\d|3[01])"
        r"(?:\.\d{1,3}){2}|192\.168(?:\.\d{1,3}){2})\b"
    ),
    "windows_user_path": re.compile(r"[A-Za-z]:\\Users\\[^\\\s]+", re.I),
    "email": re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I),
}


def load_jsonl(path: Path) -> list[dict]:
    rows = []
    with path.open("r", encoding="utf-8") as handle:
        for number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise AssertionError(f"{path}:{number}: invalid JSON: {exc}") from exc
    return rows


def check_benchmark() -> None:
    rows = load_jsonl(BENCHMARK)
    assert len(rows) == 432, f"expected 432 rows, got {len(rows)}"
    ids = [row["case_id"] for row in rows]
    assert len(ids) == len(set(ids)), "case IDs are not unique"

    by_kind = Counter(row["case_kind"] for row in rows)
    assert by_kind == Counter({"attack": 432}), by_kind

    split = load_jsonl(ATTACK_SPLIT)
    assert len(split) == 432, f"attack: expected 432, got {len(split)}"
    assert all(row["case_kind"] == "attack" for row in split)
    assert {row["case_id"] for row in split} == set(ids)

    expected_cells = {
        "C0_retrieval": {"A0_direct", "A1_intent_hijacking", "A4_task_injection"},
        "C1_screening": {
            "A0_direct", "A1_intent_hijacking", "A3_objective_drifting",
            "A4_task_injection",
        },
        "C2_route_planning": {
            "A0_direct", "A1_intent_hijacking", "A2_tool_chaining",
            "A3_objective_drifting", "A4_task_injection",
        },
        "C3_memory_planning": {
            "A0_direct", "A1_intent_hijacking", "A2_tool_chaining",
            "A3_objective_drifting", "A4_task_injection",
            "A5_memory_poisoning",
        },
    }
    observed = {
        task: {row["attack_id"] for row in rows if row["task_id"] == task}
        for task in expected_cells
    }
    assert observed == expected_cells, observed

    summary = json.loads(
        (ROOT / "benchmark" / "benchmark_v4_summary.json").read_text(encoding="utf-8")
    )
    assert "432" in json.dumps(summary), (
        "benchmark summary does not record the 432-case release"
    )

    defense_map = json.loads(
        (ROOT / "benchmark" / "defense_applicability.json").read_text(encoding="utf-8")
    )
    assert defense_map, "defense applicability map is empty"


def check_package_structure() -> None:
    missing = [relative for relative in REQUIRED_PATHS if not (ROOT / relative).is_file()]
    assert not missing, "missing required release files:\n" + "\n".join(missing)

    pyproject = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
    assert "hazard_spike*" in pyproject, "hazard_spike package is not included"
    assert "real_agents*" in pyproject, "real_agents package is not included"

    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    assert "--benchmark benchmark/benchmark_v4.jsonl" in readme, (
        "public defense-matrix command must use the released benchmark instead "
        "of the private registry"
    )

    for path in ROOT.rglob("*.py"):
        relative = path.relative_to(ROOT)
        if "__pycache__" in relative.parts:
            continue
        source = path.read_text(encoding="utf-8-sig")
        compile(source, str(relative), "exec")


def check_release_boundary() -> None:
    allowed_suffixes = {
        ".py", ".ps1", ".md", ".txt", ".toml", ".json", ".jsonl", ".example", ""
    }
    findings = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT)
        if (
            any(part in {"private", "runs"} for part in relative.parts)
            or (relative.parts[0] == "outputs" and path.name != ".gitkeep")
        ):
            findings.append(f"generated/private artifact: {relative}")
        if any(part.endswith(".egg-info") for part in relative.parts):
            findings.append(f"generated package metadata: {relative}")
        if FORBIDDEN_NAMES.search(path.name):
            findings.append(f"forbidden result-like filename: {relative}")
        if path.suffix.lower() not in allowed_suffixes:
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        for label, pattern in SECRET_PATTERNS.items():
            if pattern.search(text):
                findings.append(f"{label}: {relative}")
    assert not findings, "\n".join(findings)


def main() -> int:
    check_package_structure()
    check_benchmark()
    check_release_boundary()
    print(
        "PASS: required files, Python sources, 432 harmful cases, task/attack "
        "cells, and release-boundary checks are valid."
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
