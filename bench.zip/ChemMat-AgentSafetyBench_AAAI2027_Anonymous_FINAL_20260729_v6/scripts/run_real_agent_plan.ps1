$ErrorActionPreference = "Continue"
$root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$plan = if ($env:REAL_AGENT_PLAN) { $env:REAL_AGENT_PLAN } else { Join-Path $root "private\real_agent_plan.jsonl" }
$outDir = if ($env:REAL_AGENT_OUTPUT) { $env:REAL_AGENT_OUTPUT } else { Join-Path $root "outputs\real_agents" }
$log = Join-Path $outDir "driver.log"
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
if (-not $env:DMX_API_KEY) {
  "$(Get-Date -Format o) missing DMX_API_KEY" | Tee-Object -FilePath $log -Append
  exit 2
}
"$(Get-Date -Format o) start real-agent reruns" | Tee-Object -FilePath $log -Append
Get-Content -Path $plan | ForEach-Object {
  if (-not $_.Trim()) { return }
  $item = $_ | ConvertFrom-Json
  $outPath = Join-Path $root $item.out
  $summaryPath = Join-Path $root $item.summary
  $caseIdsPath = Join-Path $root $item.case_ids_file
  $existing = 0
  if (Test-Path $outPath) {
    $existing = (Get-Content -Path $outPath -ErrorAction SilentlyContinue | Where-Object { $_.Trim() }).Count
  }
  if ($existing -ge [int]$item.n) {
    "$(Get-Date -Format o) skip completed $($item.side) $($item.agent) $($item.attack) n=$($item.n)" | Tee-Object -FilePath $log -Append
    return
  }
  "$(Get-Date -Format o) run $($item.side) $($item.agent) $($item.attack) protocol=$($item.protocol) n=$($item.n)" | Tee-Object -FilePath $log -Append
  $args = @(
    "-m", "real_agents.work2_v2_real_agent_runner",
    "--agents", $item.agent,
    "--models", $item.model,
    "--protocols", $item.protocol,
    "--case-kinds", $item.case_kind,
    "--attacks", $item.attack,
    "--case-ids-file", $caseIdsPath,
    "--per-cell", "0",
    "--workers", "4",
    "--timeout", "240",
    "--out", $outPath,
    "--summary", $summaryPath,
    "--confirm-paid-run"
  )
  Push-Location $root
  & python @args 2>&1 | Tee-Object -FilePath $log -Append
  $code = $LASTEXITCODE
  Pop-Location
  "$(Get-Date -Format o) done $($item.side) $($item.agent) $($item.attack) exit=$code" | Tee-Object -FilePath $log -Append
}
"$(Get-Date -Format o) finished real-agent reruns" | Tee-Object -FilePath $log -Append
