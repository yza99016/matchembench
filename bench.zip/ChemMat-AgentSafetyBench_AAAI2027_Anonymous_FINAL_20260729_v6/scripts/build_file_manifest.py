from __future__ import annotations

import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "FILE_MANIFEST.sha256"
EXCLUDED_PARTS = {"__pycache__", ".git", ".venv", "private", "runs"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo"}
EXCLUDED_RELATIVE = {
    "benchmark/splits/benign_easy.jsonl",
    "benchmark/splits/benign_hard.jsonl",
    "benchmark/splits/benign_close.jsonl",
}


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def main() -> None:
    files = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or path == OUT:
            continue
        relative = path.relative_to(ROOT)
        if relative.as_posix() in EXCLUDED_RELATIVE:
            continue
        if relative.parts[0] == "outputs" and path.name != ".gitkeep":
            continue
        if EXCLUDED_PARTS.intersection(relative.parts) or any(
            part.endswith(".egg-info") for part in relative.parts
        ):
            continue
        if path.suffix.lower() in EXCLUDED_SUFFIXES:
            continue
        files.append(path)
    lines = [
        f"{digest(path)}  {path.relative_to(ROOT).as_posix()}"
        for path in sorted(files, key=lambda item: item.as_posix())
    ]
    OUT.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"wrote {len(lines)} entries to {OUT.name}")


if __name__ == "__main__":
    main()
